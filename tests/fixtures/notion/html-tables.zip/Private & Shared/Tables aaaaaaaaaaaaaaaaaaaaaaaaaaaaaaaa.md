# Tables

<table><tr><td>💡</td><td>Callouts survive as callouts.</td></tr></table>

<table><tr><td>Col A</td><td>Col B</td><td>Col C</td></tr></table>

<table><tr><td>r1a</td><td>r1b</td></tr><tr><td>r2a</td><td>r2b</td></tr></table>
