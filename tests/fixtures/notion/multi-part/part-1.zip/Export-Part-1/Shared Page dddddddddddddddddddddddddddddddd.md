# Shared Page

This page appears in both export parts (Notion can duplicate nested pages).
